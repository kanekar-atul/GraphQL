
# TypeScript-ESLint
 
[TypeScript-ESLint](https://www.typescriptlang.org/) This repository is created with standrad rule which must be implemented during JS/Typescript development.
 

## Installing

For the latest stable version:

```bash
npm install -D eslint @eslint/js @types/eslint__js typescript typescript-eslint
```
## How to run
* Please go through to understand eslint.config.js
* To run eslint :- npx eslint .
* To fix eslint issues :- npx eslint . --fix

## How to import
 - Run below cmd in your application
   - npm i typescript-test-eslint
   - make sure you have eslint.config.js else create one with same name.
   - iclude below code means you will able inherite the code from typescript-test-eslint
    ```
        import eslintBaseConfig from 'typescript-test-eslint/eslint.config.js'; 
        import tseslint from 'typescript-eslint';        
        const eslintConfig = tseslint.config(...eslintBaseConfig);
        export default eslintConfig;
    ```
     - Then you can add/update rules,plugin etc as per you application requirements.   
 


## Contribute
* 

## Documentation

*  [TypeScript Eslint](https://typescript-eslint.io/getting-started/)
*  [TypeScript Eslint Rules](https://typescript-eslint.io/rules/)

## Keywords
eslint, typescript-eslint