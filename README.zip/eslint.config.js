import eslint from '@eslint/js';
import tseslint from 'typescript-eslint';


const eslintBaseConfig = tseslint.config(
  eslint.configs.recommended,
  ...tseslint.configs.recommended,
  ...tseslint.configs.stylistic,   
  {
    rules: { 
      'semi': 'error',
      'prefer-const': 'error',
      'quotes': ['error', 'single'],
      'linebreak-style': ['error', 'unix'],
      'no-console' : 'error'
    },
    //extends: ['airbnb-typescript/base'],
    //plugins: ['@typescript-eslint'] 
  }
);
 
export default eslintBaseConfig;