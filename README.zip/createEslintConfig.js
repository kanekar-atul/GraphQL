import eslintBaseConfig from 'typescript-test-eslint/eslint.config.js'; 
import tseslint from 'typescript-eslint';

const eslintConfig =   tseslint.config(
  ...eslintBaseConfig
);
 
export default eslintConfig;