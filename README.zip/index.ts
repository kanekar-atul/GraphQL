let total = (a: any, b: any): any => {
    let c;
    return a+b
}
total(10, 20);
total('10', '20');